package testcases;
import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002_Login extends BaseClass{

@BeforeTest
   public void setValues(){
     filename="Login";
          
     	testCategory="Sanity";
		authorName="Hari";
		testName="Login";
		testDescription="Verify login functionality with valid credentials";
   }


@Test(dataProvider="fetchData")
    public void login(String username, String password) throws IOException{
    LoginPage lp=new LoginPage();
    lp.enterUsername(username)
    .enterPassword(password)
    .clickLoginButton();
    
    }

}
