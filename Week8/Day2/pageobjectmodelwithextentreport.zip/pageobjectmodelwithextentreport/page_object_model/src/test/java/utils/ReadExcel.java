package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

    //                                           Login
    public static String[][] readData(String filename) throws IOException{

      


        //Locate the Workbook
        XSSFWorkbook wb=new XSSFWorkbook("Data/"+filename+".xlsx");

        //Locating the worksheet
        XSSFSheet ws = wb.getSheet("Sheet1");

        //Count the number of rows
        //If header is available
          int rowCount = ws.getLastRowNum();
          System.out.println("rowCount is: "+rowCount);

        //If header not available
        //int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
        //System.out.println("physicalNumberOfRows is: "+physicalNumberOfRows);


        //To count the column
        //locate the row-> use method to count the column
        XSSFRow row1 = ws.getRow(1);
        int columnCount=row1.getLastCellNum();
        System.out.println("columnCount is: "+columnCount);

        //To retrieve a data
        String row1Cell1Data = ws.getRow(1).getCell(1).getStringCellValue();
        System.out.println("row1Cell1Data is: "+row1Cell1Data);

        //To retrieve entire data
        //rowCount=2
        //columnCount=3;

    String[][] data=new String[rowCount][columnCount];
        //        1      2
        for(int i=1;i<=rowCount;i++){
            //       0    1    2    3
            for(int j=0;j<columnCount;j++){
                
                String allData = ws.getRow(i).getCell(j).getStringCellValue();
                data[i-1][j]=allData;
                //data[0][0]="TestLeaf";
                //data[0][1]="Vineeth";
                //data[0][2]="Rajendran";

                //data[1][0]="Qeagle";
                //data[1][1]="Harrish";
                //data[1][2]="A";
                System.out.println("allData is: "+allData);

                //ws.getRow(1).getCell(0).getStringCellValue();  //TestLeaf     data[0][0]
                //ws.getRow(1).getCell(1).getStringCellValue();  //Vineeth      data[0][1] 
                //ws.getRow(1).getCell(2).getStringCellValue();   //Rajendran   data[0][2]

                //ws.getRow(2).getCell(0).getStringCellValue();   //Qeagle     data[1][0]
                //ws.getRow(2).getCell(1).getStringCellValue();   //Harrish    data[1][1]
                //ws.getRow(2).getCell(2).getStringCellValue();   //A          data[1][2]


            }
        }

        return data;
    }

}
