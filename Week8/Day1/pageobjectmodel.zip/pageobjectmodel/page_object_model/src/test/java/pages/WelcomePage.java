package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class WelcomePage extends BaseClass {
//                                ABCD1234
    public WelcomePage(EdgeDriver driver){
    this.driver=driver;
   //            =ABCD1234;
    }

    public MyHomePage clickCrmsfa(){

        driver.findElement(By.partialLinkText("CRM")).click();
        //MyHomePage hp=new MyHomePage();
        //return hp;
        return new MyHomePage(driver);   //ABCD1234
    }

}
