package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class LoginPage extends BaseClass {
//                          ABCD1234        
public LoginPage(EdgeDriver driver){
this.driver=driver;
//         ABCD1234
}


public LoginPage enterUsername(String username){
driver.findElement(By.id("username")).sendKeys(username);
return this;
}

public LoginPage enterPassword(String pass){
driver.findElement(By.id("password")).sendKeys(pass);
return this;
}

public WelcomePage clickLoginButton(){
driver.findElement(By.className("decorativeSubmit")).click();
//WelcomePage wp=new WelcomePage();
//return wp;
return new WelcomePage(driver);    //ABCD1234
}


}
