package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

    //public EdgeDriver driver;

    private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
    public String filename;


   public void setter(){
    driver.set(new EdgeDriver());
   }

   public EdgeDriver getter(){
    return driver.get();
   }



    @BeforeMethod
    public void preConditions(){
    //driver=new EdgeDriver();                       //ABCD1234
    setter();
    getter().get("https://leaftaps.com/opentaps");
    getter().manage().window().maximize();
    getter().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }

    @AfterMethod
      public void postConditions(){
      getter().close();
    }
    @DataProvider(name="fetchData")
    public String[][] sendData() throws IOException{
      return ReadExcel.readData(filename);    //Login
    }

}
