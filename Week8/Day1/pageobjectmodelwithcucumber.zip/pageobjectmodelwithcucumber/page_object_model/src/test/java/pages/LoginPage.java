package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {


@And("Enter the username as {string}")
public LoginPage enterUsername(String username){
getter().findElement(By.id("username")).sendKeys(username);
return this;
}

@And("Enter the password as {string}")
public LoginPage enterPassword(String pass){
getter().findElement(By.id("password")).sendKeys(pass);
return this;
}

@When("Click on the Login button")
public WelcomePage clickLoginButton(){
getter().findElement(By.className("decorativeSubmit")).click();
//WelcomePage wp=new WelcomePage();
//return wp;
return new WelcomePage();    //ABCD1234
}


}
