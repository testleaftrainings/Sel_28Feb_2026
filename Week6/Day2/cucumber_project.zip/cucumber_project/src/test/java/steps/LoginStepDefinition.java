package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition {

    public EdgeDriver driver;

   

    @And("Load the url")
     public void loadUrl(){
        driver.get("http://leaftaps.com/opentaps/control/main");
    }

     @Given("Launch the browser")
    public void launchBrowser(){
    driver=new EdgeDriver();
    }

    @And("Enter the username as Demosalesmanger")
     public void enterUsername(){
        driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
    }

    @And("Enter the password as crmsfa")
     public void enterPassword(){
        driver.findElement(By.id("password")).sendKeys("crmsfa");
    }

    @When("Click on the Login button")
     public void clickLoginButton(){
        driver.findElement(By.className("decorativeSubmit")).click();
    }

    @Then("User should be loggedin")
     public void verifyLogin(){
        System.out.println("Login successful");
    }

}
