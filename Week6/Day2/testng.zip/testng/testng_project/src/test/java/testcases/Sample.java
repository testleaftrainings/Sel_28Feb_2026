package testcases;

public class Sample {

    public static void main(String[] args) {

        String filename="CreateLead";
        
        System.out.println(filename);

        

    }

}
