package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LearnAnnotations {

 @BeforeSuite
public void executeBeforeSuite() {
    System.out.println("Before suite");
}
@BeforeTest
public void executeBeforeTest() {
    System.out.println("Before test");
}
@BeforeClass
public void executeBeforeClass() {
    System.out.println("Before class");
}
@BeforeMethod
public void executeBeforeMethod() {
    System.out.println("Before method");
}
@Test
public void executeTestCase1() {
    System.out.println("Test1");
}
@AfterMethod
public void executeAfterMethod() {
    System.out.println("After method");
}
@Test
public void executeTestCase2() {
    System.out.println("Test2");
}
@AfterClass
public void executeAfterClass() {
    System.out.println("After class");
}
@AfterTest
public void executeAfterTest() {
    System.out.println("After test");
}
@AfterSuite
public void executeAfterSuite() {
    System.out.println("After suite");
}
}


