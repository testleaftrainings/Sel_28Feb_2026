package steps;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition extends BaseClass {



   @And("Enter the username as {string}")
     public void enterUsername(String username){
        driver.findElement(By.id("username")).sendKeys(username);
    }

    @And("Enter the password as {string}")
     public void enterPassword(String password){
        driver.findElement(By.id("password")).sendKeys(password);
    }

    @When("Click on the Login button")
     public void clickLoginButton(){
        driver.findElement(By.className("decorativeSubmit")).click();
    }

    @Then("User should be loggedin")
     public void verifyLogin(){
        System.out.println("Login successful");
    }

    @But("It throws error message")
    public void verifyErrorMessage(){
        System.out.println("Error message thrown");
    }

}
