package runner;


import io.cucumber.testng.CucumberOptions;
import steps.BaseClass;

@CucumberOptions(features = "src/test/resources",glue="steps", tags="@Smoke and @Sanity and @Regression")
public class TestRunner extends BaseClass {

}


