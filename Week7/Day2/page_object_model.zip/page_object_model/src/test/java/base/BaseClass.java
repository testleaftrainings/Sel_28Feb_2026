package base;

import java.time.Duration;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseClass {

    public static EdgeDriver driver;

    @BeforeMethod
    public void preConditions(){
    driver=new EdgeDriver();                       //ABCD123
    driver.get("https://leaftaps.com/opentaps");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }

    @AfterMethod
      public void postConditions(){
      driver.close();
    }

}
